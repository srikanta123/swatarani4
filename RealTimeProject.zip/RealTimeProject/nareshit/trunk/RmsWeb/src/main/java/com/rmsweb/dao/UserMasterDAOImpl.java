package com.rmsweb.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rmsutil.dto.SearchCustomer;
import com.rmsutil.util.HQLConstants;
import com.rmsutil.util.RmsConstants;
import com.rmsutil.util.SQLConstants;
@Repository
public class UserMasterDAOImpl implements UserMasterDAO{
	@Autowired
private SessionFactory sessionFactory;
	public Long addCustomer(String customerName, String mobile,
		Long addressId, Long createdBy) {
		Long customerId=0L;
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
	try{
		
		SQLQuery query=session.createSQLQuery(SQLConstants.SQL_GET_MAX_USER_ID);
	query.addScalar(RmsConstants.CONST_USER_ID,StandardBasicTypes.LONG);
	 customerId=(Long)query.uniqueResult();
	if(customerId!=null && customerId>0){
		customerId=customerId+1;
	query=session.createSQLQuery(SQLConstants.SQL_ADD_CUSTOMER);
	query.setParameter(0,customerId);
	query.setParameter(1,customerName);
	query.setParameter(2,mobile);
	query.setParameter(3, addressId);
	query.setParameter(4,createdBy);
	query.setParameter(5,new Date());
	    int count=query.executeUpdate();
	   if(count>0){
	    tx.commit();
	   }
	   else{
	    	customerId=0L;
	    	tx.rollback();
	    }
	}
	}catch(HibernateException he){
		customerId=0L;
		tx.rollback();
	}
		return customerId;
	}
	public boolean checkMobileNumber(String mobile) {
		Boolean flag=false;
		Session session=sessionFactory.openSession();
		
		Query query=session.createQuery(HQLConstants.HQL_CHECK_MOBILE_NUMBER);
		query.setParameter(0,mobile);
		Long userId=(Long)query.uniqueResult();
		
		if(userId!=null && userId>0){
			flag=true;
		}
		session.close();
		return flag;
		
	}
	public List<SearchCustomer> 
	searchCustomer(SearchCustomer searchCustomer) {
		List<SearchCustomer> list=null;
		Boolean isFirst=true;
		if(searchCustomer.getCustomerName()!=null 
&& searchCustomer.getCustomerName().trim().length()>0
|| searchCustomer.getMobile()!=null && searchCustomer.getMobile().trim().length()>0){
	StringBuffer hql=new StringBuffer("select u.userId,u.firstName,u.mobile from com.rmsutil.dto.User as u ");
  if(searchCustomer.getCustomerName()!=null 
		  && searchCustomer.getCustomerName().trim().length()>0){	
	 hql.append(" where u.firstName like '%"+searchCustomer.getCustomerName()+"%'");
   isFirst=false;
  }
  if(searchCustomer.getMobile()!=null 
&& searchCustomer.getMobile().trim().length()>0){	
	  if(isFirst){
		  hql.append(" where u.mobile like '"+searchCustomer.getMobile()+"'");
		   isFirst=false;
		 		  
	  }else{
	hql.append(" And u.mobile like '"+searchCustomer.getMobile()+"'");	  
	  }
  }
  Session session=sessionFactory.openSession();
  Query query=session.createQuery(hql.toString());
     list= query.list();
		}
		return list;
	}
}
