package com.rmsweb.service;

public interface UserService {

	String login(String jsonLogin);

	String addCustomer(String customerName, String mobile, String addressLine1,
			Long userId);

	String checkMobileNumber(String mobile);

	String searchCustomer(String jsonSearchCustomer);

}
