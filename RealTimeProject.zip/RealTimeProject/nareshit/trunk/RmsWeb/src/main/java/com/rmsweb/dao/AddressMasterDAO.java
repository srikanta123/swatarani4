package com.rmsweb.dao;

public interface AddressMasterDAO {

	Long addCustomerAddress(String addressLine1);

}
