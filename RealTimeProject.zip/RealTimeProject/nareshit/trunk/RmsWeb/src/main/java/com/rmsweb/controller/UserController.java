package com.rmsweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.rmsutil.util.RmsConstants;
import com.rmsweb.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	private static final String SERVICE_LOGIN = "login";
	private static final String SERVICE_ADD_CUSTOMER = "addCustomer/{customerName}/{mobile}/{addressLine1}/{userId}";
	private static final String WEB_CHECK_MOBILE_NUMBER = "checkMobileNumber/{mobile}";
	private static final String WEB_SEARCH_CUSTOMER = "searchCustomer";

	@ResponseBody
	@RequestMapping(value = SERVICE_LOGIN, method = RequestMethod.POST)
	public String login(@RequestBody String jsonLogin) {
		String jsonLoginResponse = userService.login(jsonLogin);
		return jsonLoginResponse;
	}

	@ResponseBody
	@RequestMapping(value = SERVICE_ADD_CUSTOMER, method = RequestMethod.GET)
	public String addCustomer(
			@PathVariable(RmsConstants.CONST_CUSTOMER_NAME) String customerName,
			@PathVariable(RmsConstants.CONST_MOBILE) String mobile,
			@PathVariable(RmsConstants.CONST_ADDRESS_LINE1) String addressLine1,
			@PathVariable(RmsConstants.CONST_USER_ID) Long userId) {

		String jsonResponse = RmsConstants.CONST_EMPTY_JSON;
		jsonResponse = userService.addCustomer(customerName, mobile,
				addressLine1, userId);
		return jsonResponse;
	}

	@ResponseBody
	@RequestMapping(value = WEB_CHECK_MOBILE_NUMBER, method = RequestMethod.GET)
	public String checkMobileNumber(
			@PathVariable(RmsConstants.CONST_MOBILE) String mobile) {

		String jsonResponse = userService.checkMobileNumber(mobile);
		return jsonResponse;

	}
	@ResponseBody
	@RequestMapping(value=WEB_SEARCH_CUSTOMER,method=RequestMethod.POST)
public String searchCustomer(@RequestBody String jsonSearchCustomer){
	String jsonSearchCustomerResultsList=
			userService.searchCustomer(jsonSearchCustomer);
	return jsonSearchCustomerResultsList;
}
}
