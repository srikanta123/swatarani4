package com.rmsweb.dao;

import java.util.List;

import com.rmsutil.dto.Medicine;
import com.rmsutil.dto.SearchMedicineResults;

public interface MedicineMasterDAO {

	Long addMedicine(Medicine medicine);

	boolean checkBatchNumber(String batchNumber);

	List<SearchMedicineResults> searchMedicine(String medicineName,
			String medicineType);

	List<String> medicineNameAutoComplete(String medicineName);

}
