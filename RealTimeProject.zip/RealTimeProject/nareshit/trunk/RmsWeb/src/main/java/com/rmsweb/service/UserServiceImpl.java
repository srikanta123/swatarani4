package com.rmsweb.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rmsutil.dto.Login;
import com.rmsutil.dto.Response;
import com.rmsutil.dto.SearchCustomer;
import com.rmsutil.util.JsonUtil;
import com.rmsutil.util.RmsConstants;
import com.rmsweb.dao.AddressMasterDAO;
import com.rmsweb.dao.UserAuthenticationDAO;
import com.rmsweb.dao.UserMasterDAO;

@Service
public class UserServiceImpl implements UserService {
  @Autowired
	private UserAuthenticationDAO userAuthenticationDAO;
   @Autowired
    private UserMasterDAO userMasterDAO;
   @Autowired
   private AddressMasterDAO addressMasterDAO;
private static final Logger logger=Logger.getLogger(UserServiceImpl.class);
	public String login(String jsonLogin) {
		String jsonLoginResponse=RmsConstants.CONST_EMPTY_JSON;
		try{
		Login login=JsonUtil.convertToPojo(jsonLogin,Login.class);
		if(login!=null){
			login=userAuthenticationDAO.login(login);
	jsonLoginResponse=JsonUtil.convertToJson(login);
		}
		}catch(Exception exception){
	logger.error("Exception Occured while Login ::"+exception.getMessage());
		}
		return jsonLoginResponse;
	}
	public String addCustomer(String customerName, String mobile,
			String addressLine1, Long createdBy) {
		String jsonResponse=RmsConstants.CONST_EMPTY_JSON;
		try{
		Response response=new Response();
		response.setStatus((byte)0);
		response.setMessage("Customer Not Added ,Please Try Again !");
Long addressId= addressMasterDAO.addCustomerAddress(addressLine1);
if(addressId!=null && addressId>0){
Long customerId=userMasterDAO.addCustomer(customerName,mobile,addressId,createdBy);
		  if(customerId!=null &&
				  customerId>0){
			response.setData(customerId.toString());
			response.setMessage("Customer Added Successfully");
			response.setStatus((byte)1);
		  }
}
		  jsonResponse=JsonUtil.convertToJson(response);

		}catch(Exception e){
logger.error("Exception Occured while saving the customer ::"+e.getMessage());
		}
		return jsonResponse;
	}
	public String checkMobileNumber(String mobile) {
		String jsonResponse=RmsConstants.CONST_EMPTY_JSON;
		if(mobile!=null && mobile.trim().length()>0){
			try{
		Response response=new Response();
		boolean flag=userMasterDAO.checkMobileNumber(mobile);
       if(flag==true){
    	   response.setMessage("Customer Existed ");
    	   response.setStatus((byte)1);
    	   response.setData(mobile);
       }else{
    	   response.setStatus((byte)0);
    	   response.setMessage("Customer Not Existed");
       }
       jsonResponse=JsonUtil.convertToJson(response);
			}catch(Exception exception){
	logger.error("Exception Occured while checking the Mobile Number ::"+exception.getMessage());
			}
		}
		return jsonResponse;
		
	}
	public String searchCustomer(String jsonSearchCustomer) {
		String jsonSearchCustomerResultsList=RmsConstants.CONST_EMPTY_JSON;
		try{
		SearchCustomer searchCustomer=JsonUtil.convertToPojo(jsonSearchCustomer,SearchCustomer.class);
              if(searchCustomer!=null){
		List<SearchCustomer> list=userMasterDAO.searchCustomer(searchCustomer);
           jsonSearchCustomerResultsList=JsonUtil.convertToJson(list);
              }
		}catch(Exception e){
	logger.error("Exception Occured while searching the customer ::"+e.getMessage());
		}
		return jsonSearchCustomerResultsList;
	}
}
