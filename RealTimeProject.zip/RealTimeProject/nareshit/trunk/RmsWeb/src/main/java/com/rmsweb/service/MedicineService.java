package com.rmsweb.service;

public interface MedicineService {

	/**
	 * @purpose this method is used to add the medicine 
	 * @param medicineStr
	 * @return string
	 */
	String addMedicine(String medicineStr);
	/**
	 * @purpose this method is used to check the batchNumber
	 * @param batchNumber
	 * @return string
	 */
	String checkBatchNumber(String batchNumber);
	String searchMedicine(String medicineName, String medicineType);
	String medicineNameAutoComplete(String medicineName);

}
