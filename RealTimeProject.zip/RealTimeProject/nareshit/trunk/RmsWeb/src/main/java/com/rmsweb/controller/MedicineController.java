/**
 * Copyright (c) 2015,  RMS and/or its affiliates.
 *  All rights reserved.
 */
package com.rmsweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.rmsutil.util.RmsConstants;
import com.rmsweb.service.MedicineService;

/**
 * @author sathish.Bandi
 * @since 23-MAR-2015
 * @version 1.1 
 * @purpose this class is used to implement Medicine Functionalites
 */
@RestController
public class MedicineController {
	private static final String SERVICE_ADD_MEDICINE="addMedicine";
	private static final String SERVICE_CHECK_BATCH_NUMBER="checkBatchNumber/{batchNumber}";
	private static final String SERVICE_SEARCH_MEDICINE="searchMedicine/{medicineName}/{medicineType}";
	private static final String SERVICE_MEDICINE_NAME_AUTO="medicineNameAutoComplete/{medicineName}";
	@Autowired
	private MedicineService medicineService;
/**
 * @purpose this method is used to add the medicine 
 * @param medicineStr
 * @return string
 */
	@ResponseBody
	@RequestMapping(value=SERVICE_ADD_MEDICINE,method=RequestMethod.POST)
	public String addMedicine(@RequestBody String medicineStr){
		
		String jsonResponseStr=medicineService.addMedicine(medicineStr);
		return jsonResponseStr;
	}
	/**
	 * @purpose this method is used to check the batchNumber
	 * @param batchNumber
	 * @return string
	 */
	@ResponseBody
	@RequestMapping(value=SERVICE_CHECK_BATCH_NUMBER,method=RequestMethod.GET)
	public String checkBatchNumber
	(@PathVariable(RmsConstants.CONST_BATCH_NUMBER) String batchNumber){
		
		String jsonResponse=medicineService.checkBatchNumber(batchNumber);
	return jsonResponse;
	}
	/**
	 * @purpose this method is used search Medicines
	 * @param medicineName,medicineType
	 * @return string
	 */
	@ResponseBody
	@RequestMapping(value=SERVICE_SEARCH_MEDICINE,method=RequestMethod.GET)
	public  String searchMedicine(
	@PathVariable("medicineName") String medicineName,@PathVariable("medicineType") String medicineType){
		String jsonResponseList=medicineService.searchMedicine(medicineName,medicineType);
		return jsonResponseList;
	}
	/**
	 * @purpose this method is used search Medicine Names
	 * @param medicineName
	 * @return string
	 */
	@ResponseBody
	@RequestMapping(value=SERVICE_MEDICINE_NAME_AUTO,method=RequestMethod.GET)
	public String medicineNameAutoComplete(@PathVariable(RmsConstants.CONST_MEDICINE_NAME) String medicineName){
		
		String jsonResponseList=medicineService.medicineNameAutoComplete(medicineName);
	return jsonResponseList;
	}
}



