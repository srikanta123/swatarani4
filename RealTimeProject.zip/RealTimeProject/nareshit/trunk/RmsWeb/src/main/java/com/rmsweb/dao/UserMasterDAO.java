package com.rmsweb.dao;

import java.util.List;

import com.rmsutil.dto.SearchCustomer;

public interface UserMasterDAO {

	Long addCustomer(String customerName, String mobile, Long addressId,
			Long userId);

	boolean checkMobileNumber(String mobile);

	List<SearchCustomer> searchCustomer(SearchCustomer searchCustomer);

}
