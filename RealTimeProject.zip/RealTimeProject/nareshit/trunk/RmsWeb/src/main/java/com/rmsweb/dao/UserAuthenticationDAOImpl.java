package com.rmsweb.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rmsutil.dto.Login;
import com.rmsutil.dto.User;
import com.rmsutil.util.HQLConstants;

@Repository
public class UserAuthenticationDAOImpl implements UserAuthenticationDAO {
	@Autowired
	private SessionFactory sessionFactory;

	public Login login(Login login) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery(HQLConstants.HQL_LOGIN);
		query.setParameter(0, login.getUserName());
		query.setParameter(1, login.getPassword());
		query.setParameter(2, true);
		Object[] obj = (Object[]) query.uniqueResult();
		if (obj != null) {
			User user = new User();
			user.setUserId((Long) obj[0]);
			login.setUser(user);
			login.setUserRole((String) obj[1]);
		}
		return login;
	}
}
