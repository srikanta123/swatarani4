package com.rmsweb.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.directory.SearchResult;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rmsutil.dto.Medicine;
import com.rmsutil.dto.SearchMedicineResults;
import com.rmsutil.util.HQLConstants;
@Repository
public class MedicineMasterDAOImpl implements MedicineMasterDAO {
	@Autowired
	private SessionFactory sessionFactory;
	
	public Long addMedicine(Medicine medicine) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Long medicineId=(Long)session.save(medicine);
		tx.commit();
		session.close();
		return medicineId;
	}

	public boolean checkBatchNumber(String batchNumber) {
		Boolean flag=false;
		Session session=sessionFactory.openSession();
		
		Query query=session.createQuery(HQLConstants.HQL_CHECK_BATCH_NUMBER);
		query.setParameter(0,batchNumber);
		Long medicineId=(Long)query.uniqueResult();
		
		if(medicineId!=null && medicineId>0){
			flag=true;
		}
		session.close();
		return flag;
	}

	public List<SearchMedicineResults> 
	searchMedicine(String medicineName,String medicineType) {
		List<SearchMedicineResults> searchMedicineResultsList=
				new ArrayList<SearchMedicineResults>();
	Session session=sessionFactory.openSession();
	Criteria criteria=session.createCriteria(Medicine.class,"medicine");	
	   criteria.createAlias("medicine.stock","stock");
	  Projection medicineIdProjection=Projections.property("medicineId");
	  Projection batchNumProjection=Projections.property("batchNumber");
	  Projection expDateProjection=Projections.property("expDate");
	  Projection rateProjection=Projections.property("rate");
	  Projection quantityProjection=Projections.property("stock.quantity");
	  Projection dosageUnitsProjection=Projections.property("dosageUnits");
     ProjectionList plist=Projections.projectionList();
	   plist.add(medicineIdProjection);
	   plist.add(batchNumProjection);
	   plist.add(expDateProjection);
	   plist.add(rateProjection);
	   plist.add(quantityProjection);
	   plist.add(dosageUnitsProjection);
	   criteria.setProjection(plist);
	   
	   Criterion medicineNameCriterion=
			   Restrictions.ilike("medicineName",medicineName);
	   Criterion medicineTypeCriterion=
			   Restrictions.ilike("medicineType",medicineType);
	   Criterion isActiveCriterion=
			   Restrictions.eq("isActive",true);
	   criteria.add(medicineTypeCriterion);
	   criteria.add(medicineNameCriterion);
	   criteria.add(isActiveCriterion);
	   
	   criteria.addOrder(Order.asc("expDate"));
	   
	   
	      List<Object[]> list=criteria.list();
	      for(Object[] obj:list){
	   SearchMedicineResults searchMedicineResults=
			   new SearchMedicineResults();
	   searchMedicineResults.setMedicineId((Long)obj[0]);
	   searchMedicineResults.setBatchNumber((String)obj[1]);
	   searchMedicineResults.setExpDate((Date)obj[2]);
	   searchMedicineResults.setRate((Double)obj[3]);
	   searchMedicineResults.setQuantity((Integer)obj[4]);
	   searchMedicineResults.setDosageUnits((String)obj[5]);
	   searchMedicineResults.setMedicineName(medicineName);
	   searchMedicineResults.setMedicineType(medicineType);
	   searchMedicineResultsList.add(searchMedicineResults);
	      }
		return searchMedicineResultsList;
	}

	public List<String> medicineNameAutoComplete(String medicineName) {
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Medicine.class);
		Criterion medicineNameCri=Restrictions.ilike("medicineName",medicineName,MatchMode.ANYWHERE);
		
		Projection medicineNameProjection=Projections.property("medicineName");
		Projection distinctProjection=
				Projections.distinct(medicineNameProjection);
		criteria.add(medicineNameCri);
		criteria.setProjection(distinctProjection);
		criteria.addOrder(Order.asc("medicineName"));
		 List<String> list= criteria.list();
		return list;
	}

}
