package com.rmsweb.dao;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rmsutil.util.RmsConstants;
import com.rmsutil.util.SQLConstants;

@Repository
public class AddressMasterDAOImpl implements AddressMasterDAO{
	private static Logger logger=Logger.getLogger(AddressMasterDAOImpl.class);
	
	@Autowired
private SessionFactory sessionFactory;
	public Long addCustomerAddress(String addressLine1) {
		Long addressId=0L;
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		try{
	SQLQuery query=session.createSQLQuery(SQLConstants.SQL_GET_MAX_ADDRESS_ID);
	query.addScalar(RmsConstants.CONST_ADDRESS_ID,StandardBasicTypes.LONG);
	   addressId=(Long)query.uniqueResult();
	   if(addressId!=null && addressId>0){
		addressId=addressId+1;
		query=session.createSQLQuery(SQLConstants.SQL_ADD_CUSTOMER_ADDRESS);
		query.setParameter(0,addressId);
		query.setParameter(1,addressLine1);
		int count=query.executeUpdate();
		if(count>0){
			tx.commit();
		}
		else{
			tx.rollback();
			addressId=0L;
		}
	   }
		}catch(HibernateException he){
	logger.error("Exception Occured while saving Customer Address :"+he.getMessage());
			tx.rollback();
			addressId=0L;
		}
		
		return addressId;
	}

}
