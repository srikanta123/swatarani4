package com.rmsweb.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rmsutil.dto.Medicine;
import com.rmsutil.dto.Response;
import com.rmsutil.dto.SearchMedicineResults;
import com.rmsutil.util.JsonUtil;
import com.rmsutil.util.RmsConstants;
import com.rmsweb.dao.MedicineMasterDAO;

@Service
public class MedicineServiceImpl implements MedicineService{
	private static Logger logger=Logger.getLogger(MedicineServiceImpl.class);
	@Autowired
private MedicineMasterDAO medicineMasterDAO;
	/**
	 * @purpose this method is used to add the medicine 
	 * @param medicineStr
	 * @return string
	 */
	public String addMedicine(String medicineStr) {
		String jsonResponseStr=RmsConstants.CONST_EMPTY_JSON;
	Medicine medicine=JsonUtil.convertToPojo(medicineStr,Medicine.class);
	if(medicine!=null){
		try{
	Long medicineId=medicineMasterDAO.addMedicine(medicine);
	if(medicineId!=null && medicineId>0){
		Response response=new Response();
		response.setData(medicineId.toString());
		response.setMessage("Medicine Added Successfully");
		response.setStatus((byte)1);
		jsonResponseStr=JsonUtil.convertToJson(response);
	}
	
	else{
		Response response=new Response();
		response.setStatus((byte)0);
		response.setMessage("Medicine Not Added !Try Again.");
		jsonResponseStr=JsonUtil.convertToJson(response);
	}
		}catch(Exception exception){
			exception.printStackTrace();
	logger.error("Exception Occured while adding Medicine into the db ::"+exception.getMessage());
		}
	}
	
return jsonResponseStr;
	}
	/**
	 * @purpose this method is used to check the batchNumber
	 * @param batchNumber
	 * @return string
	 */
	public String checkBatchNumber(String batchNumber) {
		String jsonResponse=RmsConstants.CONST_EMPTY_JSON;
		if(batchNumber!=null && batchNumber.trim().length()>0){
			try{
		Response response=new Response();
		boolean flag=medicineMasterDAO.checkBatchNumber(batchNumber);
       if(flag==true){
    	   response.setMessage("Medicine Existed in stock,Please update the stock");
    	   response.setStatus((byte)1);
    	   response.setData(batchNumber);
       }else{
    	   response.setStatus((byte)0);
    	   response.setMessage("Medicine Not Existed in Stock");
       }
       jsonResponse=JsonUtil.convertToJson(response);
			}catch(Exception exception){
	logger.error("Exception Occured while checking the BatchNumber ::"+exception.getMessage());
			}
		}
		return jsonResponse;
	}
	public String searchMedicine(String medicineName, String medicineType) {
		String jsonResponseList=RmsConstants.CONST_EMPTY_JSON;
		if(medicineName!=null && medicineName.trim().length()>0
			&& medicineType!=null && medicineType.trim().length()>0)
		{
			try{
		List<SearchMedicineResults> list
		=medicineMasterDAO.searchMedicine(medicineName,medicineType);
		logger.info(list);
		jsonResponseList=JsonUtil.convertToJson(list);
		logger.info(jsonResponseList);
			}catch(Exception exception){
	logger.error("Exception Occured while searching the medicine :: "+exception.getMessage());
			}
		}
		return jsonResponseList;
	}
	public String medicineNameAutoComplete(String medicineName) {
		String jsonResponseList=RmsConstants.CONST_EMPTY_JSON;
		if(medicineName!=null && medicineName.trim().length()>0){
		try{
		List<String> medicineNames=medicineMasterDAO.medicineNameAutoComplete(medicineName);
		jsonResponseList=JsonUtil.convertToJson(medicineNames);
		}catch(Exception e){
	logger.error("Exception Occured while searching medicine Names ::"+e.getMessage());
		}
		}
		return jsonResponseList;
	}
}
