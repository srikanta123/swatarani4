package com.rmsweb.dao;

import com.rmsutil.dto.Login;

public interface UserAuthenticationDAO {

	Login login(Login login);

	
}
