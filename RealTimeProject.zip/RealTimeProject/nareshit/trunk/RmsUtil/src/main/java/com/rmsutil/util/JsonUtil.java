package com.rmsutil.util;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class JsonUtil {
	private static Logger logger=
			Logger.getLogger(JsonUtil.class);
	/**
	 * This method is used for 
	 converting pojo class to json object.
	 * @param javaObject
	 * @return String
	 */
	public static <T> String 
convertToJson(final T javaObject) {
		String jsonString = "{}";
		ObjectMapper objectMapper = new ObjectMapper();
     try {
			if (javaObject != null) {
jsonString = objectMapper.writeValueAsString(javaObject);
			}
		} catch(JsonGenerationException e) {
logger.error
("JsonGenerationException occured while converting to Java Object into Json String--->" + e.getMessage());
		} catch (JsonMappingException e) {
			logger.error("JsonMappingException occured while converting  POJO class into Json String--->" + e.getMessage());
		} catch (IOException e) {
			logger.error("IOException occured while converting  POJO class into json string --->" + e.getMessage());
		}
		return jsonString;
	}
	/**
	 * This method is used for converting json string to corresponding pojo  class.
	 * @param jsonString
	 * @param className
	 * @return T
	 */
	public static <T> T
	convertToPojo(final String jsonString, 
		final Class<T> className) {
		ObjectMapper objectMapper = 
			new ObjectMapper();

		T response = null;

		try {
			if (jsonString != null) {
				// Read JSON string and convert to response object
				response = 
	objectMapper.readValue(jsonString,className);
			
			}
		} catch (JsonGenerationException e) {
			logger.error("JsonGenerationException occured while converting to POJO class--->" + e.getMessage());
		} catch (JsonMappingException e) {
			logger.error("JsonMappingException occured while converting to POJO class--->" + e.getMessage());
		} catch (IOException e) {
			logger.error("JsonMappingException occured while converting to POJO class--->" + e.getMessage());

		}
		return response;
	}

	/**
	 * This method is used for converting json string to corresponding pojo
	 * class.
	 * 
	 * @param jsonString
	 * @param className
	 * @return Object
	 */
	public static <T> T convertToList(final String jsonString, final Class<?> target) {
		ObjectMapper objectMapper = new ObjectMapper();

		T response = null;

		try {
			if (jsonString != null) {
				// Read JSON string and convert to response object
				response = objectMapper.readValue(jsonString, objectMapper.getTypeFactory().constructCollectionType(List.class,Class.forName(target.getName())));
			}
		} catch (JsonGenerationException e) {
			logger.error("JsonGenerationException occured while converting to POJO class--->" + e.getMessage());
		} catch (JsonMappingException e) {
			e.printStackTrace();
			logger.error("JsonMappingException occured while converting to POJO class--->" + e.getMessage());
		} catch (IOException e) {
			logger.error("JsonMappingException occured while converting to POJO class--->" + e.getMessage());

		}catch(ClassNotFoundException e){
			logger.error("ClassNotFoundException occured while converting to POJO class--->" + e.getMessage());
		}
		return response;
	}


}
