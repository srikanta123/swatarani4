package com.rmsutil.dto;

import java.io.Serializable;
import java.util.Date;

public class SearchMedicineResults implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private Long medicineId;
private String medicineName,medicineType,dosageUnits,batchNumber;
private Integer quantity;
private Double rate;
private Date expDate;
/**
 * @return the medicineId
 */
public Long getMedicineId() {
	return medicineId;
}
/**
 * @param medicineId the medicineId to set
 */
public void setMedicineId(Long medicineId) {
	this.medicineId = medicineId;
}
/**
 * @return the medicineName
 */
public String getMedicineName() {
	return medicineName;
}
/**
 * @param medicineName the medicineName to set
 */
public void setMedicineName(String medicineName) {
	this.medicineName = medicineName;
}
/**
 * @return the medicineType
 */
public String getMedicineType() {
	return medicineType;
}
/**
 * @param medicineType the medicineType to set
 */
public void setMedicineType(String medicineType) {
	this.medicineType = medicineType;
}
/**
 * @return the dosageUnits
 */
public String getDosageUnits() {
	return dosageUnits;
}
/**
 * @param dosageUnits the dosageUnits to set
 */
public void setDosageUnits(String dosageUnits) {
	this.dosageUnits = dosageUnits;
}
/**
 * @return the batchNumber
 */
public String getBatchNumber() {
	return batchNumber;
}
/**
 * @param batchNumber the batchNumber to set
 */
public void setBatchNumber(String batchNumber) {
	this.batchNumber = batchNumber;
}
/**
 * @return the quantity
 */
public Integer getQuantity() {
	return quantity;
}
/**
 * @param quantity the quantity to set
 */
public void setQuantity(Integer quantity) {
	this.quantity = quantity;
}
/**
 * @return the rate
 */
public Double getRate() {
	return rate;
}
/**
 * @param rate the rate to set
 */
public void setRate(Double rate) {
	this.rate = rate;
}
/**
 * @return the expDate
 */
public Date getExpDate() {
	return expDate;
}
/**
 * @param expDate the expDate to set
 */
public void setExpDate(Date expDate) {
	this.expDate = expDate;
}

}
