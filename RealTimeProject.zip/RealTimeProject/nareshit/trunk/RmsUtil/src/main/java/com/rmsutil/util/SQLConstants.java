package com.rmsutil.util;

public class SQLConstants {
public static final String SQL_GET_MAX_USER_ID=
"select max(userId) as userId from UserMaster";
public static final String SQL_ADD_CUSTOMER=
"insert into UserMaster(userId,firstName,mobile,address_id,createdBy,createdDate) values(?,?,?,?,?,?)";
public static final String SQL_GET_MAX_ADDRESS_ID=
"select max(addressId) as addressId from AddressMaster";
public static final String SQL_ADD_CUSTOMER_ADDRESS=
"insert into AddressMaster(addressId,addressLine1) values(?,?)";
}
