package com.rmsutil.util;

public class HQLConstants {
public static final String HQL_CHECK_BATCH_NUMBER="select m.medicineId from com.rmsutil.dto.Medicine as m where m.batchNumber=?";
public static final String HQL_LOGIN = " select user.userId,login.userRole from com.rmsutil.dto.Login as  login  INNER JOIN login.user as user  where login.userName=? and login.password=? and login.isActive=?";
public static final String HQL_CHECK_MOBILE_NUMBER=
"select u.userId from com.rmsutil.dto.User as u where u.mobile=?";

}
