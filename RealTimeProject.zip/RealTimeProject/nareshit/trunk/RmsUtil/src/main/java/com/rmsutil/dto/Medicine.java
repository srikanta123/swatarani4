/**
 * Copyright (c) 2015,  RMS and/or its affiliates.
 *  All rights reserved.
 */
package com.rmsutil.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author sathish.Bandi
 * @since 18-MAR-2015
 * @version 1.1 this class is used to hold medicine data
 */
@Entity
@Table(name="medicineMaster",schema="rms")
public class Medicine implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GenericGenerator(name="myGenerator", strategy = "increment")
	@GeneratedValue(generator="myGenerator")
	private Long medicineId;
	
	private String medicineName;
	private String medicineType;
	@Column(name="batchNum")
	private String batchNumber;
  //@Temporal(TemporalType.DATE)
	private Date expDate;
	//@Temporal(TemporalType.DATE)
	private Date mfgDate;
	
	private String mfgBy;
	private String contents;
	private double rate;
	private String dosageUnits;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="stock_id",unique=true)
	private Stock stock;
	private Boolean isActive;
	private Long createdBy;
	@Temporal(TemporalType.DATE)
	private Date createdDate;
	private Long lastModifiedBy;
	@Temporal(TemporalType.DATE)
	private Date lastModifiedDate;

	/**
	 * @return the medicineId
	 */
	public Long getMedicineId() {
		return medicineId;
	}

	/**
	 * @param medicineId
	 *            the medicineId to set
	 */
	public void setMedicineId(Long medicineId) {
		this.medicineId = medicineId;
	}

	/**
	 * @return the medicineName
	 */
	public String getMedicineName() {
		return medicineName;
	}

	/**
	 * @param medicineName
	 *            the medicineName to set
	 */
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	/**
	 * @return the medicineType
	 */
	public String getMedicineType() {
		return medicineType;
	}

	/**
	 * @param medicineType
	 *            the medicineType to set
	 */
	public void setMedicineType(String medicineType) {
		this.medicineType = medicineType;
	}

	/**
	 * @return the batchNumber
	 */
	public String getBatchNumber() {
		return batchNumber;
	}

	/**
	 * @param batchNumber
	 *            the batchNumber to set
	 */
	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}

	/**
	 * @return the expDate
	 */
	public Date getExpDate() {
		return expDate;
	}

	/**
	 * @param expDate
	 *            the expDate to set
	 */
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	/**
	 * @return the mfgDate
	 */
	public Date getMfgDate() {
		return mfgDate;
	}

	/**
	 * @return the mfgBy
	 */
	public String getMfgBy() {
		return mfgBy;
	}

	/**
	 * @param mfgBy the mfgBy to set
	 */
	public void setMfgBy(String mfgBy) {
		this.mfgBy = mfgBy;
	}

	/**
	 * @return the contents
	 */
	public String getContents() {
		return contents;
	}

	/**
	 * @param contents the contents to set
	 */
	public void setContents(String contents) {
		this.contents = contents;
	}

	/**
	 * @return the rate
	 */
	public double getRate() {
		return rate;
	}

	/**
	 * @param rate the rate to set
	 */
	public void setRate(double rate) {
		this.rate = rate;
	}

	/**
	 * @return the dosageUnits
	 */
	public String getDosageUnits() {
		return dosageUnits;
	}

	/**
	 * @param dosageUnits the dosageUnits to set
	 */
	public void setDosageUnits(String dosageUnits) {
		this.dosageUnits = dosageUnits;
	}

	/**
	 * @return the stock
	 */
	public Stock getStock() {
		return stock;
	}

	/**
	 * @param stock the stock to set
	 */
	public void setStock(Stock stock) {
		this.stock = stock;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the createdBy
	 */
	public Long getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the lastModifiedBy
	 */
	public Long getLastModifiedBy() {
		return lastModifiedBy;
	}

	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(Long lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @param mfgDate the mfgDate to set
	 */
	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

	
}
