package com.rmsutil.dto;

import java.io.Serializable;

public class SearchCustomer implements Serializable {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private Long customerId;
private String customerName,mobile;
/**
 * @return the customerId
 */
public Long getCustomerId() {
	return customerId;
}
/**
 * @param customerId the customerId to set
 */
public void setCustomerId(Long customerId) {
	this.customerId = customerId;
}
/**
 * @return the customerName
 */
public String getCustomerName() {
	return customerName;
}
/**
 * @param customerName the customerName to set
 */
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
/**
 * @return the mobile
 */
public String getMobile() {
	return mobile;
}
/**
 * @param mobile the mobile to set
 */
public void setMobile(String mobile) {
	this.mobile = mobile;
}

}
