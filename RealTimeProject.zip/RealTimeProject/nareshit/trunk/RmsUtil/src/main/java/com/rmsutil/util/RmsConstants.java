package com.rmsutil.util;

public class RmsConstants {
public static final String CONST_MEDICINE="medicine";
public static final String CONST_BATCH_NUMBER="batchNumber";
public static final String CONST_USER_NAME="userName";
public static final String CONST_PASSWORD="password";
public static final String CONST_USER_ID="userId";
public static final String CONST_USER_ROLE="userRole";
public static final String CONST_EMPTY_JSON="{}";
public static final String CONST_MEDICINE_ID="medicineId";
public static final String CONST_MEDICINE_NAME="medicineName";
public static final String CONST_MEDICINE_TYPE="medicineType";
public static final String CONST_CUSTOMER_NAME="customerName";
public static final String CONST_MOBILE="mobile";
public static final String CONST_ADDRESS_LINE1="addressLine1";
public static final String CONST_GUEST_ADDRESS="Guest";
public static final String CONST_ADDRESS_ID = "addressId";


}
