/**
 * Copyright (c) 2015,  RMS and/or its affiliates.
 *  All rights reserved.
 */
package com.rms.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author sathish.Bandi
 * @since 18-MAR-2015
 * @version 1.1 this class is a Base Controller
 */
@Controller
public class CommonWebController {
private static final String WEB_HOME="home";
	/*
	 * this method is used to show the home page
	 * 
	 * @return modelAndView
	 */
	@RequestMapping(value =WEB_HOME,
			method = RequestMethod.GET)
	public ModelAndView home(HttpServletRequest request) {
		/*if(request.getSession(false)!=null){
			request.getSession(false).invalidate();
		}*/
		ModelAndView modelAndView =
	new ModelAndView(WEB_HOME);
		return modelAndView;
	}
}
