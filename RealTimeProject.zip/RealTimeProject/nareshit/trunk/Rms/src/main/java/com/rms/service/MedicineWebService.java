package com.rms.service;

import java.util.List;

import com.rmsutil.dto.Medicine;
import com.rmsutil.dto.SearchMedicineResults;

public interface MedicineWebService {
public String addMedicine(Medicine medicine);

public String checkBatchNumber(String batchNumber);

public List<SearchMedicineResults> searchMedicine(String medicineName,
		String medicineType);

public String medicineNameAutoComplete(String medicineName);
}
