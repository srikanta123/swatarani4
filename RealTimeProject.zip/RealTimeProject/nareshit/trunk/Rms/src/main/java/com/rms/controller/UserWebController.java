/**
 * Copyright (c) 2015,  RMS and/or its affiliates.
 *  All rights reserved.
 */
package com.rms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.rms.service.UserWebService;
import com.rmsutil.dto.Login;
import com.rmsutil.dto.SearchCustomer;
import com.rmsutil.util.RmsConstants;

/**
 * @author sathish.Bandi
 * @since 27-MAR-2015
 * @version 1.1 
 * @purpose this class is used to implement User Functionalites
 */
@Controller
public class UserWebController extends BaseWebController {
	@Autowired
	private UserWebService userWebService;
	
	private static final Logger logger=Logger.getLogger(UserWebController.class);
	private static final String WEB_HOME="home";
	private static final String WEB_LOGIN="login";
	 private static final String WEB_LOG_OUT="logout";
    private static final String WEB_CHECK_MOBILE_NUMBER="checkMobileNumber";
	private static final String WEB_ADD_CUSTOMER ="addCustomer";
	private static final String WEB_SEARCH_CUSTOMER="searchCustomer";

	private static final String WEB_SEARCH_CUSTOMER_RESULTS = "searchCustomerResults";
	@RequestMapping(value=WEB_LOGIN,method=RequestMethod.GET)
		public String showLoginForm(HttpServletRequest request){
		/*if(request.getSession(false)!=null){
			request.getSession(false).invalidate();
		}*/
		logger.info("showing LoginForm page ");
		return WEB_LOGIN;
	}
	
	 @RequestMapping(value=WEB_LOGIN,method=RequestMethod.POST)
	public ModelAndView login(@RequestParam(RmsConstants.CONST_USER_NAME) String userName,
			@RequestParam(RmsConstants.CONST_PASSWORD) String password,HttpServletRequest request){
		logger.info("Entered into login() method");
		 if(userName!=null && userName.trim().length()>0 &&
				password!=null && password.trim().length()>0){
			Login login=new Login();
			 login.setUserName(userName);
			 login.setPassword(password);
			login= userWebService.login(login);
		if(login!=null && login.getUserRole()!=null 
				&& login.getUserRole().trim().length()>0
				&& login.getUser()!=null &&
				login.getUser().getUserId()!=null){
		logger.info("Login is success ");
			request.getSession().setAttribute(RmsConstants.CONST_USER_ID,login.getUser().getUserId());
			request.getSession(false).setAttribute(RmsConstants.CONST_USER_ROLE,login.getUserRole());
			request.getSession(false).setAttribute(RmsConstants.CONST_USER_NAME,login.getUserName());
		return new ModelAndView(WEB_LOGIN);
			
		}
		else{	 
			logger.info("Login is Failure");
			request.getSession().invalidate();
			
		return new ModelAndView(WEB_LOGIN,"loginResponse","Invalid UserName (OR) Password ");
		}
		}
		 else{
			 request.getSession().invalidate();
			 
			 return new ModelAndView(WEB_LOGIN,"loginResponse","UserName (OR) Password is Empty");
		 }
	}
	 @RequestMapping(value=WEB_LOG_OUT,method=RequestMethod.GET)
public ModelAndView logout(HttpServletRequest request){	
	ModelAndView modelAndView=new 
			ModelAndView(WEB_HOME);
	modelAndView.addObject("logoutResponse","Your session expired !");
		if(request.getSession(false)!=null){
		request.getSession(false).invalidate();
		modelAndView.addObject("logoutResponse","You are logged out successfully !");
	}
	return modelAndView;
}
	 @RequestMapping(value=WEB_ADD_CUSTOMER,method=RequestMethod.GET)
	 public ModelAndView showAddCustomerPage(HttpServletRequest request){
		 if(request.getSession(false)!=null && request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
		return  new ModelAndView(WEB_ADD_CUSTOMER);	 
		 }
		 return  sessionExpired();
	 }
	 @ResponseBody
	 @RequestMapping(value=WEB_ADD_CUSTOMER,method=RequestMethod.POST)
	 public String addCustomer(@RequestParam(RmsConstants.CONST_CUSTOMER_NAME) String customerName,
			 @RequestParam(RmsConstants.CONST_MOBILE) String mobile,
			 @RequestParam(RmsConstants.CONST_ADDRESS_LINE1) String addressLine1,
			 HttpServletRequest request){
		if(request.getSession(false)!=null &&
	request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
Long userId=(Long)request.getSession(false).getAttribute(RmsConstants.CONST_USER_ID);

    String jsonResponse=userWebService.addCustomer(customerName,mobile,addressLine1,userId);
		return jsonResponse;
		}
		 
		 return jsonSessionExpired();
	 }
	 @ResponseBody
	 @RequestMapping(value=WEB_CHECK_MOBILE_NUMBER,method=RequestMethod.GET)
	 public String checkMobileNumber(
	@RequestParam(RmsConstants.CONST_MOBILE) String mobile,HttpServletRequest request){
		 if(request.getSession(false)!=null && 
				 request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
			
	String jsonResponse= userWebService.checkMobileNumber(mobile);
		return jsonResponse;
		 }
		 return jsonSessionExpired();
	 }
	 @RequestMapping(value=WEB_SEARCH_CUSTOMER,method=RequestMethod.GET)
	 public ModelAndView showSearchCustomerPage(HttpServletRequest req){
		 if(req.getSession(false)!=null &&
	req.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
			 return new ModelAndView(WEB_SEARCH_CUSTOMER);
		 }
		 return sessionExpired();
	 }
	 @RequestMapping(value=WEB_SEARCH_CUSTOMER,
			 method=RequestMethod.POST)
	 public ModelAndView searchCustomer(
	@RequestParam(RmsConstants.CONST_CUSTOMER_NAME) String customerName,
	@RequestParam(RmsConstants.CONST_MOBILE) String mobile,
			 HttpServletRequest req){
		 if(req.getSession(false)!=null &&
	req.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
	SearchCustomer searchCustomer=
			new SearchCustomer();
	searchCustomer.setCustomerName(customerName);
	searchCustomer.setMobile(mobile);
	  List<SearchCustomer> searchCustomerResultsList=
			  userWebService.searchCustomer(searchCustomer);
	return new ModelAndView(WEB_SEARCH_CUSTOMER_RESULTS,"searchCustomerResultsList",searchCustomerResultsList);
		 }
		 return sessionExpired();
	 }
	 
}
