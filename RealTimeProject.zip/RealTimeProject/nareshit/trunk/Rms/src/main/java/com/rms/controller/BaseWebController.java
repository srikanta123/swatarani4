package com.rms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.servlet.ModelAndView;

import com.rmsutil.util.JsonUtil;

public class BaseWebController {
	private static final String WEB_HOME="home";
public ModelAndView sessionExpired(){
	ModelAndView modelAndView=new
			ModelAndView(WEB_HOME,"message","Your Session Expired !Please Login");
return modelAndView;
}
public String jsonSessionExpired(){
	Map<String,String> map=new HashMap<String,String>();
	map.put("message","Your session Expired ! Please Login");
		return JsonUtil.convertToJson(map);
}
}
