package com.rms.service;

import java.util.List;

import com.rmsutil.dto.Login;
import com.rmsutil.dto.SearchCustomer;

public interface UserWebService {
public Login login(Login login);

public String addCustomer(String customerName, String mobile,
		String addressLine1, Long userId);

public String checkMobileNumber(String mobile);

public List<SearchCustomer> searchCustomer(SearchCustomer searchCustomer);

}
