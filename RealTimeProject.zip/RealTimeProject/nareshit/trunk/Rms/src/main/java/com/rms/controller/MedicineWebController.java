/**
 * Copyright (c) 2015,  RMS and/or its affiliates.
 *  All rights reserved.
 */
package com.rms.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.rms.service.MedicineWebService;
import com.rmsutil.dto.Medicine;
import com.rmsutil.dto.SearchMedicineResults;
import com.rmsutil.util.JsonUtil;
import com.rmsutil.util.RmsConstants;

/**
 * @author sathish.Bandi
 * @since 19-MAR-2015
 * @version 1.1 this class is used to implement Medicine Functionalites
 */
@Controller
public class MedicineWebController extends BaseWebController {
	private static final Logger logger=Logger.getLogger(MedicineWebController.class);
	@Autowired
	private MedicineWebService medicineWebService;

	private static final String WEB_ADD_MEDICINE = "addMedicine";
	
	private static final String WEB_CHECK_BATCH_NUM="checkBatchNumber";
    
	private static final String WEB_SEARCH_MEDICINE="searchMedicine";

	private static final String WEB_SEARCH_MEDICINE_RESULTS = "searchMedicineResults";
	private static final String WEB_MEDICINE_NAME_AUTO ="medicineNameAutoComplete";
	/**
	 * this method is used to show the addMedicinePage
	 * 
	 * @return modelAndView
	 */

	@RequestMapping(value = WEB_ADD_MEDICINE, method = RequestMethod.GET)
	public ModelAndView showAddMedicinePage(HttpServletRequest request) {
		if(request.getSession(false)!=null && request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
		ModelAndView modelAndView = new ModelAndView(WEB_ADD_MEDICINE);
		modelAndView.addObject(RmsConstants.CONST_MEDICINE, new Medicine());
		return modelAndView;
		}
		return sessionExpired();
	}

	/**
	 * this method is used to add the Medicine
	 * 
	 * @param Medicine
	 * @return String
	 */
	@ResponseBody
	@RequestMapping(value = WEB_ADD_MEDICINE, method = RequestMethod.POST)
	public String addMedicine(
			@ModelAttribute("medicine") Medicine medicine,
			HttpServletRequest request) {
		if(request.getSession(false)!=null && request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
		medicine.setIsActive(true);
		medicine.setCreatedBy((Long)request.getSession(false).getAttribute(RmsConstants.CONST_USER_ID));
		medicine.setCreatedDate(new Date());
		String jsonResponse = medicineWebService.addMedicine(medicine);
		return jsonResponse;
		}
	return jsonSessionExpired();
	}
	/**
	 *@purpose this method is used to check the batchNumber
	 * @param batchNumber
	 * @return String
	 */
	
	@ResponseBody
	@RequestMapping(value=WEB_CHECK_BATCH_NUM,method=RequestMethod.GET)
	public String checkBatchNumber
	(@RequestParam("batchNumber") String batchNumber,HttpServletRequest request){
		if(request.getSession(false)!=null && request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
			
String jsonResponse= medicineWebService.checkBatchNumber(batchNumber);
	return jsonResponse;
		}
		return jsonSessionExpired();
	}
	/**
	 *@purpose this method is used to show search Medicine Page
	 * @param request
	 * @return ModelAndView
	 */
	@RequestMapping(value=WEB_SEARCH_MEDICINE,method=RequestMethod.GET)
	public ModelAndView showSearchMedicinePage(HttpServletRequest request){
		if(request.getSession(false)!=null && request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
			
			ModelAndView modelAndView=new 
					ModelAndView(WEB_SEARCH_MEDICINE);
			return modelAndView;
		}
		return sessionExpired();
	}
	/**
	 *@purpose this method is used to  search the Medicines 
	 * @param medicineName,medicineType
	 * @return ModelAndView
	 */
	@RequestMapping(value=WEB_SEARCH_MEDICINE,method=RequestMethod.POST)
	public ModelAndView searchMedicine(
			@RequestParam(RmsConstants.CONST_MEDICINE_NAME) String medicineName,
			@RequestParam(RmsConstants.CONST_MEDICINE_TYPE) String medicineType,
			HttpServletRequest request){
		if(request.getSession(false)!=null 
		&& request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
		List<SearchMedicineResults> searchMedicineResultsList=medicineWebService.searchMedicine(medicineName,medicineType);
	logger.info(searchMedicineResultsList);
		return new ModelAndView(WEB_SEARCH_MEDICINE_RESULTS,"searchMedicineResultsList",searchMedicineResultsList);
		}
		return sessionExpired();
	}
	/**
	 *@purpose this method is used to  search the Medicine Names
	 * @param medicineName
	 * @return String
	 */
	@ResponseBody
	@RequestMapping(value=WEB_MEDICINE_NAME_AUTO,method=RequestMethod.GET)
	public String medicineNameAutocomplete(@RequestParam("medicineName") String medicineName,HttpServletRequest request){
		if(request.getSession(false)!=null && request.getSession(false).getAttribute(RmsConstants.CONST_USER_ROLE)!=null){
 String jsonResponseList=medicineWebService.medicineNameAutoComplete(medicineName);	
return jsonResponseList;		
		}
		return jsonSessionExpired();
	}
	}
