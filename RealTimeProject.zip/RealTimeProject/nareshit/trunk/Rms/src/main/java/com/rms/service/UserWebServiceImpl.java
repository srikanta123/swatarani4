package com.rms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.rmsutil.dto.Login;
import com.rmsutil.dto.SearchCustomer;
import com.rmsutil.dto.SearchMedicineResults;
import com.rmsutil.util.JsonUtil;
import com.rmsutil.util.RmsConstants;

@Service
public class UserWebServiceImpl implements UserWebService {
	private static final Logger logger = Logger
			.getLogger(UserWebServiceImpl.class);
	@Autowired
	private RestTemplate restTemplate;
	private static final String REST_LOGIN = "http://localhost:8083/RmsWeb/login";
	private static final String REST_ADD_CUSTOMER="http://localhost:8083/RmsWeb/addCustomer/{customerName}/{mobile}/{addressLine1}/{userId}";	
	private static final String REST_CHECK_MOBILE_NUMBER="http://localhost:8083/RmsWeb/checkMobileNumber/{mobile}";	
	private static final String REST_SEARCH_CUSTOMER
	= "http://localhost:8083/RmsWeb/searchCustomer";

	public Login login(Login login) {
		try {
			String jsonLogin = JsonUtil.convertToJson(login);
			jsonLogin = restTemplate.postForObject(REST_LOGIN, jsonLogin,
					String.class);
			if (jsonLogin != null && jsonLogin.trim().length() > 0) {
				login = JsonUtil.convertToPojo(jsonLogin, Login.class);
			}
		} catch (Exception exception) {
			logger.error("Exception Occured while calling RestService -->"
					+ REST_LOGIN + " ::" + exception.getMessage());
		}
		return login;
	}

	public String addCustomer(String customerName, String mobile,
			String addressLine1,  Long userId) {
		String jsonResponse=RmsConstants.CONST_EMPTY_JSON;
		if(addressLine1.trim().length()==0){
			addressLine1=RmsConstants.CONST_GUEST_ADDRESS;
		}
		Map<String,Object> map=new HashMap<String,Object>();
		map.put(RmsConstants.CONST_CUSTOMER_NAME,customerName);
		map.put(RmsConstants.CONST_MOBILE,mobile);
		map.put(RmsConstants.CONST_ADDRESS_LINE1,addressLine1);
		map.put(RmsConstants.CONST_USER_ID,userId);
		try{
			
	jsonResponse=restTemplate.getForObject(REST_ADD_CUSTOMER,String.class,map);		
		}
		catch(Exception e){
			logger.error("Exception Occured while calling RestService -->"
					+ REST_ADD_CUSTOMER + " ::" + e.getMessage());
			
		}
		return jsonResponse;
	}
	public String checkMobileNumber(String mobile) {
		String jsonResponse=RmsConstants.CONST_EMPTY_JSON;
		try{
		Map<String,String> map=new HashMap<String,String>();
		map.put(RmsConstants.CONST_MOBILE,mobile);
		jsonResponse=restTemplate.getForObject(REST_CHECK_MOBILE_NUMBER,String.class,map);
		}catch(Exception exception){
	logger.error("Exception Occured while calling RestService-->"+REST_CHECK_MOBILE_NUMBER+" :: "+mobile);
		}
		return jsonResponse;
	}

	public List<SearchCustomer> 
	searchCustomer(SearchCustomer searchCustomer) {
List<SearchCustomer> searchCustomerResultsList=null;
		String jsonSearchCustomer=JsonUtil.convertToJson(searchCustomer);
		try{
		String jsonSearchCustomerResults=restTemplate.postForObject(REST_SEARCH_CUSTOMER,jsonSearchCustomer,String.class);
	logger.info("Response of searchCustomer ::"+jsonSearchCustomerResults);
		if(jsonSearchCustomerResults.trim().length()>0){
			searchCustomerResultsList=JsonUtil.<List<SearchCustomer>> convertToList(jsonSearchCustomerResults,SearchCustomer.class);
		}
		}
		catch(Exception e){
	logger.error("Exception Occured while calling RestService -->"+REST_SEARCH_CUSTOMER+" :: "+e.getMessage());
		}
		return searchCustomerResultsList;
	}

}
