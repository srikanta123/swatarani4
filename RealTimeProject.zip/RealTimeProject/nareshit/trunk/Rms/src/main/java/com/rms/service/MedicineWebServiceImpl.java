package com.rms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.rmsutil.dto.Medicine;
import com.rmsutil.dto.SearchMedicineResults;
import com.rmsutil.util.JsonUtil;
import com.rmsutil.util.RmsConstants;
@Service
public class MedicineWebServiceImpl implements MedicineWebService{
 private static final Logger logger=Logger.getLogger(MedicineWebServiceImpl.class);
 private static final String REST_ADD_MEDICINE="http://localhost:8083/RmsWeb/addMedicine";
private static final String REST_CHECK_BATCH_NUMBER="http://localhost:8083/RmsWeb/checkBatchNumber/{batchNumber}";	
private static final String REST_SEARCH_MEDICINE="http://localhost:8083/RmsWeb/searchMedicine/{medicineName}/{medicineType}";	
private static final String REST_MEDICINE_NAME_AUTO=
"http://localhost:8083/RmsWeb/medicineNameAutoComplete/{medicineName}";	
 
 @Autowired
	private RestTemplate restTemplate;
	
	public String addMedicine(Medicine medicine) {
		String jsonResponseStr=RmsConstants.CONST_EMPTY_JSON;
		String medicineStr=JsonUtil.convertToJson(medicine);
		try{
		 jsonResponseStr
		=restTemplate.postForObject(REST_ADD_MEDICINE,medicineStr,String.class);
		}catch(Exception exception){
logger.error("Exception Occured while calling RestService -->"+REST_ADD_MEDICINE+" ::"+exception.getMessage());
		}
		logger.info("response of addMedicine() ::"+jsonResponseStr);
		return jsonResponseStr;
	}

	public String checkBatchNumber(String batchNumber) {
		String jsonResponse=RmsConstants.CONST_EMPTY_JSON;
		try{
		Map<String,String> map=new HashMap<String,String>();
		map.put(RmsConstants.CONST_BATCH_NUMBER,batchNumber);
		jsonResponse=restTemplate.getForObject(REST_CHECK_BATCH_NUMBER,String.class,map);
		}catch(Exception exception){
	logger.error("Exception Occured while calling RestService-->"+REST_CHECK_BATCH_NUMBER+" :: "+batchNumber);
		}
		return jsonResponse;
	}
	public List<SearchMedicineResults> 
	searchMedicine(String medicineName,String medicineType) {
		List<SearchMedicineResults> list=null;
	Map<String,String> map=new HashMap<String,String>();
	map.put(RmsConstants.CONST_MEDICINE_NAME,medicineName);
	map.put(RmsConstants.CONST_MEDICINE_TYPE,medicineType);
	try{
   String jsonResponseList=restTemplate.getForObject(REST_SEARCH_MEDICINE,String.class,map);
	logger.info(jsonResponseList);
   if(jsonResponseList!=null && jsonResponseList.trim().length()>0){
list = JsonUtil.<List<SearchMedicineResults>> convertToList(jsonResponseList, SearchMedicineResults.class);
	}
	}catch(Exception exception){
		logger.error("Exception Occured while calling RestService -->"+REST_SEARCH_MEDICINE+"::"+exception.getMessage());
	}
		return list;
	}

	public String medicineNameAutoComplete(String medicineName) {
		String jsonResponseList=RmsConstants.CONST_EMPTY_JSON;
	 Map<String,String> map=new HashMap<String,String>();
		map.put(RmsConstants.CONST_MEDICINE_NAME,medicineName);
		try{
		jsonResponseList=restTemplate.getForObject(REST_MEDICINE_NAME_AUTO,String.class,map);
		}catch(Exception e){
	logger.error("Exception Occured while calling RestService -->"+REST_MEDICINE_NAME_AUTO+" :: "+e.getMessage());
		}
		logger.info(jsonResponseList);
		return jsonResponseList;
	}
	}
